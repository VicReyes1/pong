//
//  CTrabajos_y_oficios.hpp
//  Inclusion
//
//  Created by Victor Serrano Reyes  on 28/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#ifndef CTrabajos_y_oficios_hpp
#define CTrabajos_y_oficios_hpp
#include <iostream>
using namespace std;
#include <stdio.h>
class CTrabajos_y_oficios{
public:
    virtual void Trabajar(){
        cout<<"Estoy trabajando "<<endl;
    }
};
#endif /* CTrabajos_y_oficios_hpp */

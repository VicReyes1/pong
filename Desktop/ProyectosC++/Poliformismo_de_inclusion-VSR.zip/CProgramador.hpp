//
//  CProgramador.hpp
//  Inclusion
//
//  Created by Victor Serrano Reyes  on 28/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#ifndef CProgramador_hpp
#define CProgramador_hpp
#include "CTrabajos_y_oficios.hpp"
#include <stdio.h>
class CProgramador : public CTrabajos_y_oficios{
    void Trabajar(){
        cout<<"Trabajo programando un videojuego "<<endl;
    }
};
#endif /* CProgramador_hpp */

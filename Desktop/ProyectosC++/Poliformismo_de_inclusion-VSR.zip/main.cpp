//
//  main.cpp
//  Inclusion
//
//  Created by Victor Serrano Reyes  on 28/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#include <iostream>
#include "CProgramador.hpp"
#include "CTrabajos_y_oficios.hpp"
#include "CMecanico.hpp"
#include "CPiloto.hpp"
#include "CPeluquero.hpp"
#include "CPanadero.hpp"
#include "CArquitecto.hpp"
#include "CMedico.hpp"
int main(int argc, const char * argv[]) {
    CTrabajos_y_oficios *Trabajos[10];
    Trabajos[0]=new CTrabajos_y_oficios;
    Trabajos[1]=new CProgramador;
    Trabajos[2]=new CMecanico;
    Trabajos[3]=new CPiloto;
    Trabajos[4]=new CPeluquero;
    Trabajos[5]=new CPanadero;
    Trabajos[6]=new CArquitecto;
    Trabajos[7]=new CMedico;
    
    for(int i=1;i<=7;i++){
        Trabajos[i] -> Trabajar();
    };
    
    return 0;
}

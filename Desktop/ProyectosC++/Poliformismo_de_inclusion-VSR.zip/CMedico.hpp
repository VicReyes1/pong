//
//  CMedico.hpp
//  Inclusion
//
//  Created by Victor Serrano Reyes  on 28/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#ifndef CMedico_hpp
#define CMedico_hpp
#include "CTrabajos_y_oficios.hpp"
#include <stdio.h>
class CMedico : public CTrabajos_y_oficios{
    void Trabajar(){
        cout<<"Trabajo ayudando a la lucha contra el COVID-19"<<endl;
    }
};
#endif /* CMedico_hpp */

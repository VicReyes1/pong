//
//  CPiloto.hpp
//  Inclusion
//
//  Created by Victor Serrano Reyes  on 28/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#ifndef CPiloto_hpp
#define CPiloto_hpp
#include "CTrabajos_y_oficios.hpp"
#include <stdio.h>
class CPiloto : public CTrabajos_y_oficios{
    void Trabajar(){
        cout<<"Trabajo pilotando un avión "<<endl;
    }
};
#endif /* CPiloto_hpp */

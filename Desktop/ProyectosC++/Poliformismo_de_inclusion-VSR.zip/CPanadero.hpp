//
//  CPanadero.hpp
//  Inclusion
//
//  Created by Victor Serrano Reyes  on 28/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#ifndef CPanadero_hpp
#define CPanadero_hpp
#include "CTrabajos_y_oficios.hpp"
#include <stdio.h>
class CPanadero : public CTrabajos_y_oficios{
    void Trabajar(){
        cout<<"Trabajo horneando y vendiendo pan "<<endl;
    }
};
#endif /* CPanadero_hpp */

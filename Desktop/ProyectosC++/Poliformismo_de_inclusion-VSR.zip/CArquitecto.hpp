//
//  CArquitecto.hpp
//  Inclusion
//
//  Created by Victor Serrano Reyes  on 28/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#ifndef CArquitecto_hpp
#define CArquitecto_hpp
#include "CTrabajos_y_oficios.hpp"
#include <stdio.h>
class CArquitecto : public CTrabajos_y_oficios{
    void Trabajar(){
        cout<<"Trabajo diseñando una casa"<<endl;
    }
};
#endif /* CArquitecto_hpp */

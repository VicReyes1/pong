//
//  CMecanico.hpp
//  Inclusion
//
//  Created by Victor Serrano Reyes  on 28/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#ifndef CMecanico_hpp
#define CMecanico_hpp
#include "CTrabajos_y_oficios.hpp"
#include <stdio.h>
class CMecanico : public CTrabajos_y_oficios{
    void Trabajar(){
        cout<<"Trabajo reparando un carro"<<endl;
    }
};
#endif /* CMecanico_hpp */

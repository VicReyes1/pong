//
//  CTapiz.hpp
//  Silla con Tapiz
//
//  Created by Victor Serrano Reyes  on 20/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#ifndef CTapiz_hpp
#define CTapiz_hpp
#include <iostream>
#include <string>
#include <stdio.h>
using namespace std;
class CTapiz{
public:
    int color;
    string textura;
    string material;
public:
    CTapiz();
    ~CTapiz();
    float metros_a_utilizar();
    void tapizar_asientos();
    void hacer_ropa();
    
};
#endif /* CTapiz_hpp */

//
//  CTapiz.cpp
//  Silla con Tapiz
//
//  Created by Victor Serrano Reyes  on 20/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#include "CTapiz.hpp"
CTapiz::CTapiz(){
    color=1;
    textura="lisa";
    material ="Tela";
}
CTapiz::~CTapiz(){
  
}

float CTapiz::metros_a_utilizar(){
    float m;
    return m;
}
void CTapiz::tapizar_asientos(){
    cout<<"El sillon se ha tapizado"<<endl;
}
void CTapiz::hacer_ropa(){
    cout<<"Ropa hecha "<<endl;
}


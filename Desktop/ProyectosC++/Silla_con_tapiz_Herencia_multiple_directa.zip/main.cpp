//
//  main.cpp
//  Silla con Tapiz
//
//  Created by Victor Serrano Reyes  on 20/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#include <iostream>
#include "CAsiento_con_tapiz.hpp"
int main() {
    CAsiento_con_tapiz Asiento;
    Asiento.usar_como_escalera();
    Asiento.tapizar_asientos();
    
    /*En este codico obsvervamos como el sillon finalmente obtiene tanto las características de el esqueleto de un sillon de lo que esta hecho, así como lo de afeura, su tapiz.
     */
    Asiento.muestraDatos();
    
    return 0;
}

//
//  CAsiento.hpp
//  Silla con Tapiz
//
//  Created by Victor Serrano Reyes  on 20/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#ifndef CAsiento_hpp
#define CAsiento_hpp

#include <stdio.h>
#include <iostream>
#include <string>
#include <stdio.h>
using namespace std;
class CAsiento{
public:
    string materialS;
    float altura;
    float ancho;
    string material_colchon;
public:
    CAsiento();
    ~CAsiento();
    void sentarse();
    void recostarse();
    void usar_como_escalera();
};
#endif /* CAsiento_hpp */

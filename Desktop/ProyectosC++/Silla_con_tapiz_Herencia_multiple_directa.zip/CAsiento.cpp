//
//  CAsiento.cpp
//  Silla con Tapiz
//
//  Created by Victor Serrano Reyes  on 20/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#include "CAsiento.hpp"
CAsiento::CAsiento(){
    materialS = "madera";
    altura = 100;
    ancho = 45;
    material_colchon = "esponja";
}
CAsiento::~CAsiento(){
    
}
void CAsiento::sentarse(){
    cout<<"Usted se ha sentado"<<endl;
}
void CAsiento::recostarse(){
    cout<<"Usted se ha recostado"<<endl;
}
void CAsiento::usar_como_escalera(){
    cout<<"Usted se ha subido"<<endl;
}

//
//  CAsiento_con_tapiz.hpp
//  Silla con Tapiz
//
//  Created by Victor Serrano Reyes  on 20/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#ifndef CAsiento_con_tapiz_hpp
#define CAsiento_con_tapiz_hpp
#include "CAsiento.hpp"
#include "CTapiz.hpp"
#include <stdio.h>
class CAsiento_con_tapiz:public CAsiento,public CTapiz{
public:
    CAsiento_con_tapiz();
    ~CAsiento_con_tapiz();
    void ensuciarse();
    void lavarse();
    void muestraDatos();
    };
#endif /* CAsiento_con_tapiz_hpp */

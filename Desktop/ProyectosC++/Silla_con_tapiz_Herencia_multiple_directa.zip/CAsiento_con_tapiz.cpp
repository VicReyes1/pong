//
//  CAsiento_con_tapiz.cpp
//  Silla con Tapiz
//
//  Created by Victor Serrano Reyes  on 20/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#include "CAsiento_con_tapiz.hpp"
CAsiento_con_tapiz::CAsiento_con_tapiz(){
   
}
CAsiento_con_tapiz::~CAsiento_con_tapiz(){
    
}
void CAsiento_con_tapiz::ensuciarse(){
    cout<<"El asiento se ha ensusiado"<<endl;
}
void CAsiento_con_tapiz::lavarse(){
    cout<<"El asiento se ha limpiado"<<endl;
}
void CAsiento_con_tapiz::muestraDatos(){
    cout<<"El sillon tiene unas dimensiones altura de "<<altura<<" de altura en cm y un ancho de "<<ancho<<endl;
    cout<<"Y su tapiz es "<<material<<" con un codigo de color "<<color<< " y una textura "<<textura<<endl;
    
}

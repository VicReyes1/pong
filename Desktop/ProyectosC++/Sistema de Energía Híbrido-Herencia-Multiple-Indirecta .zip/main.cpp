//
//  main.cpp
//  Sistema de carga hirbrido
//
//  Created by Victor Serrano Reyes  on 20/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#include <iostream>
#include "SistemaH.cpp"
int main(int argc, const char * argv[]) {
    CSistemaH casa_hibrida;
   /* Este es un codigo que se basa en las energias renovables en casa, teniendo como clase abuelo, las energias renobables, las clases padres, dos ejemlos de energias renovables, y finalmente la clase hija, que simboliza como una casa puede funcionar con dos energías diferentes.
    
    */
    
  
    return 0;
}

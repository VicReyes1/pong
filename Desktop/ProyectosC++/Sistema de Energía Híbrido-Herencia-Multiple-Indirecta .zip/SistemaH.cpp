//
//  SistemaH.cpp
//  Sistema de carga hirbrido
//
//  Created by Victor Serrano Reyes  on 20/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#include "SistemaH.hpp"
CSistemaH::CSistemaH(){
    cantidad_energias = 2;
    energia_dominante = "Solar";
    
}
CSistemaH::~CSistemaH(){
    
}
void CSistemaH:: utilzar_energias_ambas_energias(){
    cout<<"Utilizando ambas energías"<<endl;
}
void CSistemaH::alternar_energias(){
    cout<<"Utilizando la energía "<<energia_dominante<<endl;
}

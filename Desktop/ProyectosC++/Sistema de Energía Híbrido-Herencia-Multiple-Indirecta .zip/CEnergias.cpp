//
//  CEnergias.cpp
//  Sistema de carga hirbrido
//
//  Created by Victor Serrano Reyes  on 20/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#include "CEnergias.hpp"
CEnergiasRenovables::CEnergiasRenovables(){
    nombre_energia = "";
    dispositivos ="";
    porcentaje_de_eficiencia = 0;
    
}
CEnergiasRenovables::~CEnergiasRenovables(){
    
}
void CEnergiasRenovables::instalar_dispositivos(){
    cout<<"Instalando "<<dispositivos<<endl;
}
void CEnergiasRenovables::Almacenar_energia(){
    cout<<"Energia Guardada "<<endl;
}
void CEnergiasRenovables::cargar_baterias(){
    cout<<"La bateria se ha cargado al maximo"<<endl;
}
void CEnergiasRenovables::mantenimiento(){
    cout<<"Realizando servicio de mantenimiento "<<endl;
}



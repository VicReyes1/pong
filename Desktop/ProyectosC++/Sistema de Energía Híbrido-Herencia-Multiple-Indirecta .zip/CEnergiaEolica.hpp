//
//  CEnergiaEolica.hpp
//  Sistema de carga hirbrido
//
//  Created by Victor Serrano Reyes  on 20/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#ifndef CEnergiaEolica_hpp
#define CEnergiaEolica_hpp
#include "CEnergias.hpp"
#include <stdio.h>
class CEnergiaEolica: public CEnergiasRenovables{
private:
    string marca_elice;
    float costo_elice;
public:
    CEnergiaEolica();
    ~CEnergiaEolica();
    void girar_de_acuerdo_al_viento();
    void convertir_energia_cinetica();
};
#endif /* CEnergiaEolica_hpp */

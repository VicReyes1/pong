//
//  SistemaH.hpp
//  Sistema de carga hirbrido
//
//  Created by Victor Serrano Reyes  on 20/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#ifndef SistemaH_hpp
#define SistemaH_hpp
#include "CEnergiaSolar.hpp"
#include "CEnergiaEolica.hpp"
#include <stdio.h>
#endif /* SistemaH_hpp */

class CSistemaH:public CEnergiaSolar, public CEnergiaEolica{
    int cantidad_energias;
    string energia_dominante;
public:
    CSistemaH();
    ~CSistemaH();
    void utilzar_energias_ambas_energias();
    void alternar_energias();
};

//
//  CEnergiaSolar.hpp
//  Sistema de carga hirbrido
//
//  Created by Victor Serrano Reyes  on 20/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#ifndef CEnergiaSolar_hpp
#define CEnergiaSolar_hpp
#include "CEnergias.hpp"
#include <stdio.h>
class CEnergiaSolar: public CEnergiasRenovables{
private:
    string marca_panel_solar;
    float costo_panel;
public:
    CEnergiaSolar();
    ~CEnergiaSolar();
    void absorver_radiacion_solar();
    void convertir_energia();
};
#endif /* CEnergiaSolar_hpp */

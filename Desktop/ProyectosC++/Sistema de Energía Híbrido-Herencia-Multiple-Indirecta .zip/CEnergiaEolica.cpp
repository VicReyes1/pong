//
//  CEnergiaEolica.cpp
//  Sistema de carga hirbrido
//
//  Created by Victor Serrano Reyes  on 20/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#include "CEnergiaEolica.hpp"
CEnergiaEolica::CEnergiaEolica(){
    nombre_energia = "Eolica";
    dispositivos = "Turbinas";
    porcentaje_de_eficiencia = 68;
    marca_elice="AirSET";
    costo_elice =9000;
}
CEnergiaEolica::~CEnergiaEolica(){
    
}
void CEnergiaEolica::girar_de_acuerdo_al_viento(){
    cout<<"Girando"<<endl;
}
void CEnergiaEolica::convertir_energia_cinetica(){
    cout<<"Convirtiendo"<<endl;
}

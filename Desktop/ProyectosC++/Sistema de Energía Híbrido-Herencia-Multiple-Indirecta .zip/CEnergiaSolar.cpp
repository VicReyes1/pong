//
//  CEnergiaSolar.cpp
//  Sistema de carga hirbrido
//
//  Created by Victor Serrano Reyes  on 20/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#include "CEnergiaSolar.hpp"
CEnergiaSolar::CEnergiaSolar(){
    nombre_energia = "Solar";
    dispositivos = "Paneles";
    porcentaje_de_eficiencia = 88;
    marca_panel_solar = "SunSet";
    costo_panel= 15000;
    
}
CEnergiaSolar::~CEnergiaSolar(){
    
}
void CEnergiaSolar::absorver_radiacion_solar(){
    cout<<"Coloque el panel en buena posicion para que haga su funcion "<<endl;
}

void CEnergiaSolar::convertir_energia(){
    cout<<"convirtiendo energia "<<endl;
}

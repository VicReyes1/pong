//
//  CEnergias.hpp
//  Sistema de carga hirbrido
//
//  Created by Victor Serrano Reyes  on 20/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#ifndef CEnergias_hpp
#define CEnergias_hpp
#include <iostream>
#include <stdio.h>
#include <string>
using namespace std;
class CEnergiasRenovables{
    
    
   
public:
    string nombre_energia;
    string dispositivos;
    float porcentaje_de_eficiencia;
    
    CEnergiasRenovables();
    ~CEnergiasRenovables();
    void instalar_dispositivos();
    void Almacenar_energia();
    void cargar_baterias();
    void mantenimiento();

};
#endif /* CEnergias_hpp */

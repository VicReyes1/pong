//
//  CIncidencias.hpp
//  Autores: Victor Serrano Reyes
//  Matrículas: A01274694
//  Fecha de creación: 09/09/20.
//  Fecha última edición: 10/09/20.

#ifndef CIncidencias_hpp
#define CIncidencias_hpp

#include <stdio.h>
#include <iostream>
#include <string>
#include <vector>
#include <time.h>
using namespace std;
class CIncidencias{
public:
    string mes;
    int dia;
    string hora;
    string ip;
    string falla;
    int horas;
    int minutos;
    int segundos;
    int indicaMes;
    
    //El constructor en este caso aquí recive el vector de la función principal, posteriormente inicializa los atributos de la clase tales como "mes","dia","hora","ip","falla", todos de tipo string. Con el valor que se obtenga de la posición determinada en el vector, de igual manera atributos númericos ya separables como el día, los transforma de string a entero, ya que todos los datos almacenados en el vector son de tipo string.
    CIncidencias( vector<std::string>datos){
        mes=datos[0];
        cout<<"Mes: "<<mes<<endl;
        dia=std::stoi(datos[1]);
        cout<<"Dia: "<<dia<<endl;
        hora=datos[2];
        cout<<"Hora "<<hora<<endl;
        ip=datos[3];
        cout<<"IP: "<<ip<<endl;
        for (int i=4; i<datos.size();i++)
            falla.append(datos[i] + ' ');
            cout<< "Identifique la falla como: "<<falla<<endl;
    };
    
    //Este método recibe en horasx el valor guardado en la varibale horaD en el programa principal el fue obtenido de el atributo público "hora" de la clase Cfecha, minsx recibe el valor guardado en la varibale "minD" en el programa principal el fue obtenido de el atributo público "minuto" de la clase Cfecha y segsx  recibe el valor guardado en la varibale "segD" en el programa principal el fue obtenido de el atributo público "segundo" de la clase Cfecha. Posteriormente el método inicializa los atributos de esta clase restantes, tales como "horas","minutos", "segundos" al igularlos con la información recebida respectivamente, para finaliar, este método recibe un mes en segundos, primero dependiendo el mes, inicializa la variable faltante indicaMes con el número entero el cual es el número de mes en el calendario ordinario - 1, no tiene retorno.
    void establecerFecha(int horasx, int minsx, int segsx){
        horas=horasx;
        minutos=minsx;
        segundos=segsx;
        if (mes=="Jun"){
            indicaMes=5;
        }else if (mes=="Jul"){
            indicaMes=6;
        }else if (mes=="Aug"){
            indicaMes=7;
        }else if (mes=="Sep"){
            indicaMes=8;
        }else if (mes=="Oct"){
            indicaMes=9;
        }
    };
    
    //Este métodod no recibe de el programa principal ningun parámetro, es un método in-line en cual retorna un atributo tipo time_t, en este caso una fecha, se declara la variable donde estará almacenada la fecha con nombre fecha1, posteriormente se llama a la estrcutua tm, para poder usar sus atributos para formar una fecha, finalmente se establecen el valor de estos atributos en la variable datosTM1, como todos los registros son del mismo año, predeterminadamente pondremos 120 que es referente al 2020, en tm_mon colocaremos el valor de el atributo entero indica mes de esta clase, en tm_day el atributo entero dia, en tm_hour el atributo entero horas y tm_Sec el atributo entero segundos, finalmente almacenamos esto en la varieble time_t ya establecida y la retornamos para que pueda ser usada.
    time_t regresaFecha(){
        time_t fecha1;
        struct tm datosTM1 = { 0 };
        datosTM1.tm_year = 120; datosTM1.tm_mon = indicaMes; datosTM1.tm_mday = dia;
        datosTM1.tm_hour = horas; datosTM1.tm_min = minutos; datosTM1.tm_sec = segundos;
        fecha1 = mktime(&datosTM1);
        
        return fecha1;
    }
    
};
#endif /* CIncidencias_hpp */

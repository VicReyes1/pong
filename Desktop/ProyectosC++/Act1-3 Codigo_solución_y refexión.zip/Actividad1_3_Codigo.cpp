
//  Autores: Victor Serrano Reyes
//  Matrículas: A01274694
//  Fecha de creación: 09/09/20.
//  Fecha última edición: 13/09/20.
//  Descripción: Este programa obtiene información de una bitácora de incidencias, la cual contiene en desorden, las fechas de una falla, la hora de la falla y de que se trata la falla, consecuente, este programa se encarga de leer, dividir y proccesar este archivo para, por medio de un método de ordenamiento, en este caso quicksort, para ordenar las fallas de forma ascendente, posteriormente el codigo crea un nuevo archivo, da formato y guarda las incidencias ya ordenadas, de igual forma el codigo es capaz de unicamente mostrar en pantalla y ya con formato, las incidencias delimitadas por unas fechas en específico.

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <time.h>
#include "CIncidencias.hpp"
#include "Cfecha.hpp"
using namespace std;
//funcion para ordenar lista de numeros
//el quicksort necesita una lista, la 1ra y ultima posicion del array
//el pivote es el valor medio de la lista
void quicksort(CIncidencias* inc[], int primero, int ultimo) {
    int central=0, i=0, j=0;
    time_t pivote=0;
    central = (primero + ultimo) / 2; //posicion central del array
    //capturar valor del medio del array
    pivote = inc[central]->regresaFecha();
    //esta igualacion es para separar los segmentos
    i = primero;
    j = ultimo;
    //toda lista necesita un recorrido, en este caso con do while
    do {
        //separando en 2 partes el array
        while (inc[i]->regresaFecha() < pivote) i++; //separando valores menores del pivote
        while (inc[j]->regresaFecha() > pivote) j--; //separando valores mayores del pivote
        if (i <= j) {
            //se hace el intercambio de valores
            CIncidencias* temporal;
            temporal = inc[i];
            inc[i] = inc[j];
            inc[j] = temporal;
            i++;
            j--;
        }
    } while (i <= j);
    if (primero < j)
        quicksort(inc, primero, j);
    if (i < ultimo)
        quicksort(inc, i, ultimo);
}

//Esta función tiene como objetivo regresar una fecha en la función main, esta función utiliza el mes que ingrese el usuario como parámetro, el dia y la hora, en el momento de pedir los registros exactos, para despues regresar un atributo de tipo time.
time_t creaFecha(string mes,int dia,int hora){
    int mes2=0;
    if (mes=="Jun"){
        mes2=5;
    }else if (mes=="Jul"){
        mes2=6;
    }else if (mes=="Aug"){
        mes2=7;
    }else if (mes=="Sep"){
        mes2=8;
    }else if (mes=="Oct"){
        mes2=9;
    }
    time_t fecha;
    struct tm datosTM1 = { 0 };
    datosTM1.tm_year = 120; datosTM1.tm_mon = mes2; datosTM1.tm_mday = dia;
    datosTM1.tm_hour = hora; datosTM1.tm_min = 0; datosTM1.tm_sec = 0;
    fecha= mktime(&datosTM1);
    
    return fecha;
}

// Esta función recive un conjunto de datos de tipo string, una característcia que es separable, en este caso utilizamos espacios en blanco para la información y los ":" para las fechas, posterioremnte e introducido como otro parámetro, esto lo almacena en un vector que nosotros previamente realizamos previamente en la función principal, esta función no tiene retorno sin embargo modifica el vector.
void tokenize(std::string const &str, const char delim, std::vector<std::string> &out)
{
    size_t start;
    size_t end = 0;

    while ((start = str.find_first_not_of(delim, end)) != std::string::npos)
    {
        end = str.find(delim, start);
        out.push_back(str.substr(start, end - start));
    }
}

//Función principal del programa, es donde implementamos las acciones de cada cosa, en la primera parte, se delara la cadena así como el archivo de donde obtenemos los datos, posteriormente se crean los objetos de la clase Cincidencias, despúes declaramos el vecotor a utilizar y un idx, posteriormente encotramos el bucle while que lee el archivo hasta su final, y uno por uno obtiene los atributos del arreglo, los guarda en un vector, utiliza la función tokenize para separarlo , y posterioremnte eso se envía a una hubicación de el arreglo de objetos dada por idx. finalmente se cierra el archivo.

//Parte 2 Se encuentra la declaración de un nuevo vector, y se crea un arreglo de objetos de la clase Cfecha, y posteriormente se declaran variables extras para manejar la fecha,empeiza un bucle for el cual empieza en 0 y el límite es <idx, posteriormente este ciclo obtiene la hora de CIncidencias, la manda a separar a Cfecha  la cual se almacena en unas variables y los valores de dichas variables son pasados al método establecer fecha de CIncidencias.

//Parte 3 Se utiliza la función quicksort donde se le pasa el arreglo de objetos de CIncidencias, se pasa el 0 para el indice 0 y tambíen se le pasa la cantidad de elementos -1, se crea y se abre un archivo, através de un ciclo for se guarda en el nuevo archivo el mes, dia, hora, y el ip de la falla, todo esto ya en orden, finalmente se cierra el archivo y aparece un mensaje en pantalla sobre la creación exitosa de un archivo.

//Parte 4 Establece variables de tipo time_t, así como algunas otras de tipo entero para la cración de datos, se le pregunta al usuario un més, dia, hora, de partida, estos datos se pasa a la función creaFecha el cual regresa una fecha y se almacena en una varibale de tipo time_t, este procceso se repite para la fecha final, finalmente el programa recorre los datos ya ordenados por medio de in ciclo for y si se cumple la condición dada por el if, referente a que la fecha obtenida se encuentra entre las fechas de las variables tipo time_t, se imprimen las características de la falla, dadas por el archivo Cincindecnias, tales como mes, dia, hora, ip y la falla.
int main(int argc, const char * argv[]) {
    cout<<"Lectura de incidentes en el servidor" <<endl;
    std::string cadena="";
    std::ifstream file("/Users/victorserranoreyes/Desktop/lecturaArchivos/lecturaArchivos/bitacora.txt");
    CIncidencias *incidencia;
    CIncidencias *incidenciasServidor[17000];
    vector<std::string> elementos;
    int idx=0;
    while (!file.eof()) {
        elementos.clear();
        std::getline(file,cadena);
        tokenize(cadena, ' ', elementos);
        incidencia = new CIncidencias(elementos);
        incidenciasServidor[idx]=incidencia;
        idx++;
        cout<<"             "<<endl;
    }
    file.close();
    
    vector<std::string> fechas;
    CFecha *fecha;
    CFecha *fechaSep[17000];
    string fechasCad0="";
    std::string mesG="";
       string horaG="";
    int horaD=0;
    int minD=0;
    int segD=0;
    cout<<endl<<endl<<"Leyendos los archivos de el arreglo incidencias!"<<endl;
    for(int i=0;i<idx;i++){
        fechas.clear();
        horaG=incidenciasServidor[i]->hora;
        tokenize(horaG, ':', fechas);
        fecha=new CFecha(fechas);
        fechaSep[i]=fecha;
        horaD=fechaSep[i]->hora;
        minD=fechaSep[i]->minuto;
        segD=fechaSep[i]->segundo;
        incidenciasServidor[i]->establecerFecha(horaD, minD, segD);
        
    };
   
    quicksort(incidenciasServidor, 0, idx-1);
    ofstream file2;
    file2.open("Archivo_Ordenado.txt");
    for(int idxNew=idx-1;0<=idxNew;idxNew--){
    file2<<"Mes de falla: "<<incidenciasServidor[idxNew]->mes<<endl;
    file2<<"Dia de falla: "<<incidenciasServidor[idxNew]->dia<<endl;
    file2<<"Hora de falla: "<<incidenciasServidor[idxNew]->hora<<endl;
    file2<<"IP de la falla: "<<incidenciasServidor[idxNew]->ip<<endl;
    file2<<"Identifiqué la falla como: "<<incidenciasServidor[idxNew]->falla<<endl;
    file2<<"___________________________"<<endl<<endl;
    }
    file2.close();
    cout<<"!Se creado con éxito un archivo en orden¡"<<endl;
    
    time_t fechaIn = 0,fecha2Fin = 0;
    string mes="";
    int dia=0;
    int hora=0;
    cout<<"Ingresa fecha inicial de busqueda "<<endl;
    cout<<"Mes: ";cin>>mes;
    cout<<"Dia: ";cin>>dia;
    cout<<"Hora: ";cin>>hora;
    fechaIn=creaFecha(mes, dia, hora);
    cout<<"Ingresa fecha final de busqueda: "<<endl;
    cout<<"Mes: ";cin>>mes;
    cout<<"Dia: ";cin>>dia;
    cout<<"Hora: ";cin>>hora;
    fecha2Fin=creaFecha(mes, dia, hora);
    for(int idxNew=idx-1;0<=idxNew;idxNew--){
        if (incidenciasServidor[idxNew]->regresaFecha()>=fechaIn && incidenciasServidor[idxNew]->regresaFecha()<=fecha2Fin){
        cout<<"Mes de falla: "<<incidenciasServidor[idxNew]->mes<<endl;
        cout<<"Dia de falla: "<<incidenciasServidor[idxNew]->dia<<endl;
        cout<<"Hora de falla: "<<incidenciasServidor[idxNew]->hora<<endl;
        cout<<"IP de la falla: "<<incidenciasServidor[idxNew]->ip<<endl;
        cout<<"Identifiqué la falla como: "<<incidenciasServidor[idxNew]->falla<<endl;
        cout<<"___________________________"<<endl<<endl;
        }
    };
    
    return 0;
}

//
//  Cfecha.hpp
//  Autores: Victor Serrano Reyes
//  Matrículas: A01274694
//  Fecha de creación: 09/09/20.
//  Fecha última edición: 10/09/20.
#ifndef Cfecha_hpp
#define Cfecha_hpp

#include <stdio.h>
#include <string>
#include <vector>
#include <iostream>
using namespace std;
class CFecha{
public:
    int hora;
    int minuto;
    int segundo;
    
    //El constructor de esta clase recibe la información del vector fechas, creado en el programa principal, el cual contiene la información separada de el atributo horas de la clase CIncidencias por la función tokenize. Este contrusctor convierte los datos string a simples números enteros, que son con los cuales se inicializan los valores de los atributos de esta clase(Cfecha).
    CFecha(vector<std::string>fecha){
        hora=std::stoi(fecha[0]);
        minuto=std::stoi(fecha[1]);
        segundo=std::stoi(fecha[2]);
    }
    
};
#endif /* Cfecha_hpp */

//
//
//  recursivo
//  Autores: Victor Serrano Reyes, Jose Pablo Cobos Asturia, Erik Martín Martinez Ibarra Edgar Daniel Acosta Rosales
//  Matrículas: A01274694, A01274631, A01276269, A01274694
//  Fecha de creación y edición: 14/08/20.
//  Descripción: Este programa pide un número base y una potencia, para elevar el número base, lo hace de manera itinerativa y tambíen de manera recursiva, llamando a la respectiva función, posteiormente se imprimen los resultados para ambos casos, mostrando en la consola, que los resultados son los mismos y son correctos.

//

#include <iostream>
using namespace std;

int potenciasItinera (int x, int y);

int potenciasRecursion (int x,int y);

//Función principal del programa, la cual se encarga establecer e inicalizar las variables, posteriormente pregunta al usario el numero base y la potencia, lo almacena en x y y respectivamente, ese valor lo manda a las respectivas funciones, las cuales hacen el procceso y se imprime el resultado
int main(int argc, const char * argv[]) {
    int x=0 , y=0;
    cout<<"Ingresa el numero base "<<endl;
    cin>>x;
    cout<<"Ingresa su potencia "<<endl;
    cin>>y;
    cout<<"El resultado por Intineracion es: "<<potenciasItinera(x, y)<<endl;
    cout<<"El resultado por Recursividad es: "<<potenciasRecursion(x, y)<<endl;
    
};
//Esta función realizará el calculo de la potencia por Itineración, siendo "x" el número base y "y" el la potencia, la función regresa un entero, que en este caso es la operación.
int potenciasItinera(int x, int y){
    int resultado = 1;
    for(int t=0;t<y;t++){
        resultado=resultado*x;
    }
    return resultado;
};

//Esta función realizará el calculo de la potencia por Recursividad, siendo "x" el número base y "y" el la potencia, la función regresa un entero, que en este caso es la operación.
int potenciasRecursion(int x,int y){
    if (y==0){
        x=1;
    }else{
        x=x*potenciasRecursion(x, y-1);
    }
    return x;
};


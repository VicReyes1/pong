//
//  CEnvio.cpp
//  Paqueteria
//
//  Created by Victor Serrano Reyes  on 20/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#include "CEnvio.hpp"
CEnvio::CEnvio(){
    nombre=" ";
    direccion=" ";
    ciudad=" ";
    estado=" ";
    remitente=" ";
    destinatario=" ";
    codigo_postal=0;
    envio_standar =109;
}
CEnvio::~CEnvio(){
    
}
double CEnvio::calculaCosto(){
    return 0;
}


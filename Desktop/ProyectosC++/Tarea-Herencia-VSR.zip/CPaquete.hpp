//
//  CPaquete.hpp
//  Paqueteria
//
//  Created by Victor Serrano Reyes  on 20/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#ifndef CPaquete_hpp
#define CPaquete_hpp
#include "CEnvio.hpp"
#include <stdio.h>
class CPaquete:public CEnvio{
public:
    CPaquete();
    ~CPaquete();
    double largo,ancho,profundidad,peso,costoXkilo;
    
    double calculaCosto();
    void PedirDatos();
};
#endif /* CPaquete_hpp */

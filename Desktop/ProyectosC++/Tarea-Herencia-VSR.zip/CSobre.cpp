//
//  CSobre.cpp
//  Paqueteria
//
//  Created by Victor Serrano Reyes  on 20/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#include "CSobre.hpp"
CSobre::CSobre(){
    largo =0;
    ancho =0;
    cargo =25;
}
CSobre::~CSobre(){
    
}
double CSobre::calculaCosto(){
    double costoSobre = 0 ;
    if ((largo>25 or largo>30)&&(ancho>30 or ancho>25)){
    costoSobre=(envio_standar+cargo);
    
    }else{
        costoSobre=envio_standar;
    }
    return costoSobre;
}
void CSobre::pedirDatos(){
    cout <<"nombre"<<": "<<endl;cin>>nombre;
    cout <<"direccion"<<": "<<endl;cin>>direccion;
    cout <<"ciudad"<<": "<<endl;cin>>ciudad;
    cout <<"estado"<<": "<<endl;cin>>estado;
    cout <<"remitente"<<": "<<endl;cin>>remitente;
    cout <<"destinatario"<<": "<<endl;cin>>destinatario;
    cout <<"codigo postal"<<": "<<endl;cin>>codigo_postal;
     cout <<largo<<": "<<endl;cin>>largo;
     cout <<ancho<<": "<<endl;cin>>ancho;
}


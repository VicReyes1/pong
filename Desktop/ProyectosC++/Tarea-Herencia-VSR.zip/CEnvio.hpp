//
//  CEnvio.hpp
//  Paqueteria
//
//  Created by Victor Serrano Reyes  on 20/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#ifndef CEnvio_hpp
#define CEnvio_hpp
#include <iostream>
#include <string>
using namespace std;
#include <stdio.h>
class CEnvio{
public:
    string nombre,direccion,ciudad,estado,remitente,destinatario;
    int codigo_postal;
    double envio_standar;
    CEnvio();
    ~CEnvio();
    double calculaCosto();
    
};
#endif /* CEnvio_hpp */

//
//  CPaquete.cpp
//  Paqueteria
//
//  Created by Victor Serrano Reyes  on 20/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#include "CPaquete.hpp"
CPaquete::CPaquete(){
    largo=0;
    ancho=0;
    profundidad=0;
    peso=0;
    costoXkilo=7;
}
CPaquete::~CPaquete(){
    
}
 
double CPaquete::calculaCosto(){
    double costoPaquete;
    
    costoPaquete = (peso*costoXkilo)+envio_standar;
    return costoPaquete;
    
}
void CPaquete::PedirDatos(){
    cout <<"nombre"<<": "<<endl;cin>>nombre;
    cout <<"direccion"<<": "<<endl;cin>>direccion;
    cout <<"ciudad"<<": "<<endl;cin>>ciudad;
    cout <<"estado"<<": "<<endl;cin>>estado;
    cout <<"remitente"<<": "<<endl;cin>>remitente;
    cout <<"destinatario"<<": "<<endl;cin>>destinatario;
    cout <<"codigo postal"<<": "<<endl;cin>>codigo_postal;
     cout <<"largo"<<": "<<endl;cin>>largo;
     cout <<"ancho"<<": "<<endl;cin>>ancho;
     cout <<"profundidad"<<": "<<endl;cin>>profundidad;
     cout <<"peso"<<": "<<endl;cin>>peso;
    
}


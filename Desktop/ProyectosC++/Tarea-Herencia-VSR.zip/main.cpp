//
//  main.cpp
//  Paqueteria
//
//  Created by Victor Serrano Reyes  on 20/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#include <iostream>
#include "CSobre.hpp"
#include "CPaquete.hpp"
int main(int argc, const char * argv[]) {
    
    int op;
    cout<<"Desea enviar un paquete o una carta (1.Paquete 2.carta)"<<endl;
    cin>>op;
    if (op==1){
        int x;
        CPaquete paqute;
        paqute.PedirDatos();
        x = paqute.calculaCosto();
        cout<<"El costo es "<<x<<" pesos mx"<<endl;
    }else if (op==2){
        int x2;
        CSobre sobre;
        sobre.pedirDatos();
        x2=sobre.calculaCosto();
        cout<<"El costo es "<<x2<<" pesos mx"<<endl;
    }
    return 0;
}

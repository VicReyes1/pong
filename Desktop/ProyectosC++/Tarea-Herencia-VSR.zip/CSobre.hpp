//
//  CSobre.hpp
//  Paqueteria
//
//  Created by Victor Serrano Reyes  on 20/05/20.
//  Copyright © 2020 Victor Serrano Reyes . All rights reserved.
//

#ifndef CSobre_hpp
#define CSobre_hpp
#include "CEnvio.hpp"
#include <stdio.h>
class CSobre:public CEnvio{
public:
    CSobre();
    ~CSobre();
    double largo,ancho,cargo;
    double calculaCosto();
    void pedirDatos();
    
};
#endif /* CSobre_hpp */
